<?php

namespace App\Http\Controllers;

use App\Models\Debt;
use App\Models\Expense;
use Illuminate\Http\Request;

class DebtController extends Controller
{
    public function index()
{
    $owedByMe = Debt::where('type', 'owed_by_me')->orderBy('created_at', 'desc')->get();
    $owedToMe = Debt::where('type', 'owed_to_me')->orderBy('created_at', 'desc')->get();
    $expenses = Expense::orderBy('created_at', 'desc')->get();
    
    $totalOwedByMe = $owedByMe->sum('amount');
    $totalOwedToMe = $owedToMe->sum('amount');
    $totalExpenses = $expenses->sum('amount');
    $debtBalance = $totalOwedToMe - $totalOwedByMe;
    
    // استرجاع القسم النشط من session
    $activeTab = session('active_tab', 'owedByMe');
    
    return view('index', compact('owedByMe', 'owedToMe', 'expenses', 'totalOwedByMe', 'totalOwedToMe', 'totalExpenses', 'debtBalance', 'activeTab'));
}
    
   public function storeDebt(Request $request)
{
    $request->validate([
        'person_name' => 'required|string|max:255',
        'amount' => 'required|numeric|min:0.01',
        'type' => 'required|in:owed_by_me,owed_to_me'
    ]);
    
    Debt::create($request->all());
    
    // تحويل الاسم لصيغة camelCase
    $tabName = $request->type === 'owed_by_me' ? 'owedByMe' : 'owedToMe';
    session(['active_tab' => $tabName]);
    
    return redirect()->back()->with('success', 'تم الإضافة بنجاح');
}
    
    public function storeExpense(Request $request)
{
    $request->validate([
        'amount' => 'required|numeric|min:0.01'
    ]);
    
    Expense::create($request->all());
    
    // حفظ القسم النشط
    session(['active_tab' => 'expenses']);
    
    return redirect()->back()->with('success', 'تم الإضافة بنجاح');
}
    
    public function deleteDebt($id)
{
    $debt = Debt::findOrFail($id);
    $tabName = $debt->type === 'owed_by_me' ? 'owedByMe' : 'owedToMe';
    $debt->delete();
    
    // حفظ القسم النشط
    session(['active_tab' => $tabName]);
    
    return redirect()->back()->with('success', 'تم الحذف بنجاح');
}
    
    public function deleteExpense($id)
{
    Expense::findOrFail($id)->delete();
    
    // حفظ القسم النشط
    session(['active_tab' => 'expenses']);
    
    return redirect()->back()->with('success', 'تم الحذف بنجاح');
}

    public function updateDebt(Request $request, $id)
{
    $request->validate([
        'person_name' => 'required|string|max:255',
        'amount' => 'required|numeric|min:0.01'
    ]);
    
    $debt = Debt::findOrFail($id);
    $debt->update($request->only(['person_name', 'amount']));
    
    // حفظ القسم النشط
    $tabName = $debt->type === 'owed_by_me' ? 'owedByMe' : 'owedToMe';
    session(['active_tab' => $tabName]);
    
    return redirect()->back()->with('success', 'تم التعديل بنجاح');
}

public function updateExpense(Request $request, $id)
{
    $request->validate([
        'amount' => 'required|numeric|min:0.01'
    ]);
    
    $expense = Expense::findOrFail($id);
    $expense->update($request->only(['amount']));
    
    // حفظ القسم النشط
    session(['active_tab' => 'expenses']);
    
    return redirect()->back()->with('success', 'تم التعديل بنجاح');
}
}