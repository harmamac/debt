<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تتبع الديون والمصاريف</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header-card">
            <h1 class="main-title">تتبع الديون والمصاريف</h1>
            
            <!-- Summary Cards -->
            <div class="summary-grid">
                <div class="summary-card summary-card-red">
                    <div class="summary-label summary-label-red">أنا مدين لهم</div>
                    <div class="summary-amount summary-amount-red">{{ number_format($totalOwedByMe, 2) }}</div>
                </div>
                
                <div class="summary-card summary-card-green">
                    <div class="summary-label summary-label-green">مدينين لي</div>
                    <div class="summary-amount summary-amount-green">{{ number_format($totalOwedToMe, 2) }}</div>
                </div>
            </div>

            <!-- Debt Balance -->
            <div class="balance-card 
                @if($debtBalance > 0) balance-card-positive
                @elseif($debtBalance < 0) balance-card-negative
                @else balance-card-neutral @endif">
                <div class="balance-header">
                    <span class="balance-label 
                        @if($debtBalance > 0) balance-label-positive
                        @elseif($debtBalance < 0) balance-label-negative
                        @else balance-label-neutral @endif">
                        الرصيد الكلي للديون:
                    </span>
                    <div class="balance-amount 
                        @if($debtBalance > 0) balance-amount-positive
                        @elseif($debtBalance < 0) balance-amount-negative
                        @else balance-amount-neutral @endif">
                        {{ $debtBalance > 0 ? '+' : '' }}{{ number_format($debtBalance, 2) }}
                    </div>
                </div>
                <div class="balance-status 
                    @if($debtBalance > 0) balance-status-positive
                    @elseif($debtBalance < 0) balance-status-negative
                    @else balance-status-neutral @endif">
                    @if($debtBalance > 0) لك عند الناس
                    @elseif($debtBalance < 0) عليك للناس
                    @else متعادل @endif
                </div>
            </div>

            <!-- Total Expenses -->
            <div class="summary-card summary-card-blue">
                <div class="summary-label summary-label-blue">إجمالي المصاريف</div>
                <div class="summary-amount summary-amount-blue">{{ number_format($totalExpenses, 2) }}</div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="main-card" x-data="{ tab: '{{ $activeTab }}' }">
            <div class="tabs-container">
                <button @click="tab = 'owedByMe'" 
                    :class="tab === 'owedByMe' ? 'tab-button tab-button-red' : 'tab-button tab-button-inactive'">
                    مدين لهم
                </button>
                <button @click="tab = 'owedToMe'" 
                    :class="tab === 'owedToMe' ? 'tab-button tab-button-green' : 'tab-button tab-button-inactive'">
                    مدينين لي
                </button>
                <button @click="tab = 'expenses'" 
                    :class="tab === 'expenses' ? 'tab-button tab-button-blue' : 'tab-button tab-button-inactive'">
                    مصاريفي
                </button>
            </div>

            <!-- Forms -->
            <div class="form-container">
                <!-- Debt Form (Owed By Me) -->
                <form x-show="tab === 'owedByMe'" x-cloak method="POST" action="{{ route('debt.store') }}">
                    @csrf
                    <input type="hidden" name="type" value="owed_by_me">
                    <input type="text" name="person_name" placeholder="اسم الشخص" required class="form-input form-input-mb">
                    <div class="form-input-group">
                        <input type="number" name="amount" step="0.01" placeholder="المبلغ" required class="form-input">
                        <button type="submit" class="btn btn-red">إضافة</button>
                    </div>
                </form>

                <!-- Debt Form (Owed To Me) -->
                <form x-show="tab === 'owedToMe'" x-cloak method="POST" action="{{ route('debt.store') }}">
                    @csrf
                    <input type="hidden" name="type" value="owed_to_me">
                    <input type="text" name="person_name" placeholder="اسم الشخص" required class="form-input form-input-mb">
                    <div class="form-input-group">
                        <input type="number" name="amount" step="0.01" placeholder="المبلغ" required class="form-input">
                        <button type="submit" class="btn btn-green">إضافة</button>
                    </div>
                </form>

                <!-- Expense Form -->
                <form x-show="tab === 'expenses'" x-cloak method="POST" action="{{ route('expense.store') }}">
                    @csrf
                    <div class="form-input-group">
                        <input type="number" name="amount" step="0.01" placeholder="المبلغ" required class="form-input">
                        <button type="submit" class="btn btn-blue">إضافة</button>
                    </div>
                </form>
            </div>

            <!-- Lists -->
            <div class="list-container">
                <!-- Owed By Me List -->
                <div x-show="tab === 'owedByMe'" x-cloak>
                    @if($owedByMe->isEmpty())
                        <div class="list-empty">لا توجد سجلات بعد</div>
                    @else
                        <div class="list-items">
                            @foreach($owedByMe as $debt)
                            <div class="item-card" x-data="{ editing: false }">
                                <!-- View Mode -->
                                <div x-show="!editing">
                                    <div class="item-header">
                                        <div class="item-content">
                                            <div class="item-person-name">{{ $debt->person_name }}</div>
                                            <div class="item-amount">{{ number_format($debt->amount, 2) }}</div>
                                        </div>
                                        <div class="item-actions">
                                            <button @click="editing = true" class="btn btn-blue btn-small">تعديل</button>
                                            <form method="POST" action="{{ route('debt.delete', $debt->id) }}">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-red btn-small">حذف</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="item-datetime">
                                        <span>📅 {{ $debt->created_at->format('Y/m/d') }}</span>
                                        <span>🕐 {{ $debt->created_at->format('H:i') }}</span>
                                    </div>
                                </div>
                                
                                <!-- Edit Mode -->
                                <form x-show="editing" x-cloak method="POST" action="{{ route('debt.update', $debt->id) }}" class="edit-form">
                                    @csrf
                                    @method('PUT')
                                    <input type="text" name="person_name" value="{{ $debt->person_name }}" required class="form-input">
                                    <input type="number" name="amount" step="0.01" value="{{ $debt->amount }}" required class="form-input">
                                    <div class="edit-actions">
                                        <button type="submit" class="btn btn-green btn-small btn-flex-1">حفظ</button>
                                        <button type="button" @click="editing = false" class="btn btn-gray btn-small btn-flex-1">إلغاء</button>
                                    </div>
                                </form>
                            </div>
                            @endforeach
                        </div>
                    @endif
                </div>

                <!-- Owed To Me List -->
                <div x-show="tab === 'owedToMe'" x-cloak>
                    @if($owedToMe->isEmpty())
                        <div class="list-empty">لا توجد سجلات بعد</div>
                    @else
                        <div class="list-items">
                            @foreach($owedToMe as $debt)
                            <div class="item-card" x-data="{ editing: false }">
                                <!-- View Mode -->
                                <div x-show="!editing">
                                    <div class="item-header">
                                        <div class="item-content">
                                            <div class="item-person-name">{{ $debt->person_name }}</div>
                                            <div class="item-amount">{{ number_format($debt->amount, 2) }}</div>
                                        </div>
                                        <div class="item-actions">
                                            <button @click="editing = true" class="btn btn-blue btn-small">تعديل</button>
                                            <form method="POST" action="{{ route('debt.delete', $debt->id) }}">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-red btn-small">حذف</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="item-datetime">
                                        <span>📅 {{ $debt->created_at->format('Y/m/d') }}</span>
                                        <span>🕐 {{ $debt->created_at->format('H:i') }}</span>
                                    </div>
                                </div>
                                
                                <!-- Edit Mode -->
                                <form x-show="editing" x-cloak method="POST" action="{{ route('debt.update', $debt->id) }}" class="edit-form">
                                    @csrf
                                    @method('PUT')
                                    <input type="text" name="person_name" value="{{ $debt->person_name }}" required class="form-input">
                                    <input type="number" name="amount" step="0.01" value="{{ $debt->amount }}" required class="form-input">
                                    <div class="edit-actions">
                                        <button type="submit" class="btn btn-green btn-small btn-flex-1">حفظ</button>
                                        <button type="button" @click="editing = false" class="btn btn-gray btn-small btn-flex-1">إلغاء</button>
                                    </div>
                                </form>
                            </div>
                            @endforeach
                        </div>
                    @endif
                </div>

                <!-- Expenses List -->
                <div x-show="tab === 'expenses'" x-cloak>
                    @if($expenses->isEmpty())
                        <div class="list-empty">لا توجد سجلات بعد</div>
                    @else
                        <div class="list-items">
                            @foreach($expenses as $expense)
                            <div class="item-card" x-data="{ editing: false }">
                                <!-- View Mode -->
                                <div x-show="!editing">
                                    <div class="item-header">
                                        <div class="item-content">
                                            <div class="item-amount">{{ number_format($expense->amount, 2) }}</div>
                                        </div>
                                        <div class="item-actions">
                                            <button @click="editing = true" class="btn btn-blue btn-small">تعديل</button>
                                            <form method="POST" action="{{ route('expense.delete', $expense->id) }}">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-red btn-small">حذف</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="item-datetime">
                                        <span>📅 {{ $expense->created_at->format('Y/m/d') }}</span>
                                        <span>🕐 {{ $expense->created_at->format('H:i') }}</span>
                                    </div>
                                </div>
                                
                                <!-- Edit Mode -->
                                <form x-show="editing" x-cloak method="POST" action="{{ route('expense.update', $expense->id) }}" class="edit-form">
                                    @csrf
                                    @method('PUT')
                                    <input type="number" name="amount" step="0.01" value="{{ $expense->amount }}" required class="form-input">
                                    <div class="edit-actions">
                                        <button type="submit" class="btn btn-green btn-small btn-flex-1">حفظ</button>
                                        <button type="button" @click="editing = false" class="btn btn-gray btn-small btn-flex-1">إلغاء</button>
                                    </div>
                                </form>
                            </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</body>
</html>