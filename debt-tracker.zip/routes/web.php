<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DebtController;

Route::get('/', [DebtController::class, 'index'])->name('home');
Route::post('/debt', [DebtController::class, 'storeDebt'])->name('debt.store');
Route::post('/expense', [DebtController::class, 'storeExpense'])->name('expense.store');
Route::delete('/debt/{id}', [DebtController::class, 'deleteDebt'])->name('debt.delete');
Route::delete('/expense/{id}', [DebtController::class, 'deleteExpense'])->name('expense.delete');
Route::put('/debt/{id}', [DebtController::class, 'updateDebt'])->name('debt.update');
Route::put('/expense/{id}', [DebtController::class, 'updateExpense'])->name('expense.update');